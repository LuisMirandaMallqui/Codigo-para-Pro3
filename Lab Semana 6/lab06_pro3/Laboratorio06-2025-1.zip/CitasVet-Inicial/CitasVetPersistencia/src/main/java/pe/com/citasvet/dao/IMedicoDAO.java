package pe.com.citasvet.dao;

import pe.com.citasvet.modelo.Medico;

public interface IMedicoDAO extends ICrud<Medico> {
}