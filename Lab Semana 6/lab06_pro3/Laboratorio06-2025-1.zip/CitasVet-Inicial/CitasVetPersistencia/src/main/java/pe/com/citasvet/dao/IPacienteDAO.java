package pe.com.citasvet.dao;

import pe.com.citasvet.modelo.Paciente;

public interface IPacienteDAO extends ICrud<Paciente> {
}