package pe.com.citasvet.dao;

import pe.com.citasvet.modelo.Tutor;

public interface ITutorDAO extends ICrud<Tutor> {
}